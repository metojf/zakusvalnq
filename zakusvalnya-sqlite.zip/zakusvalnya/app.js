'use strict';

// Менюто е описано на едно място. Цените се проверяват отново и на сървъра.
const PRODUCTS = [
  { id: 'classic', name: 'Класически сандвич', category: 'sandwich', description: 'Шунка, кашкавал, домат, свежа салата и сос.', price: 5.50, icon: '🥪', tag: 'Любим избор' },
  { id: 'chicken', name: 'Пилешки сандвич', category: 'sandwich', description: 'Пилешко филе, кашкавал, маруля и чеснов сос.', price: 6.50, icon: '🥙', tag: 'С пилешко' },
  { id: 'caprese', name: 'Капрезе', category: 'sandwich', description: 'Моцарела, домат, босилек и песто.', price: 6.00, icon: '🍅', tag: 'Свежо предложение' },
  { id: 'tuna', name: 'Сандвич с риба тон', category: 'sandwich', description: 'Риба тон, царевица, краставица и лек сос.', price: 6.80, icon: '🥗', tag: 'Различен вкус' },
  { id: 'veggie', name: 'Вегетариански сандвич', category: 'sandwich', description: 'Кашкавал, печени чушки, краставица и салата.', price: 5.80, icon: '🥬', tag: 'Без месо' },
  { id: 'water', name: 'Минерална вода', category: 'drink', description: 'Негазирана вода · 500 мл.', price: 1.50, icon: '💧', tag: '500 мл' },
  { id: 'ayran', name: 'Айрян', category: 'drink', description: 'Освежаващ айрян · 300 мл.', price: 2.00, icon: '🥛', tag: '300 мл' },
  { id: 'juice', name: 'Портокалов сок', category: 'drink', description: 'Плодов сок · 250 мл.', price: 2.80, icon: '🍊', tag: '250 мл' },
  { id: 'tea', name: 'Студен чай', category: 'drink', description: 'Студен чай с лимон · 500 мл.', price: 2.50, icon: '🧃', tag: '500 мл' }
];

const cart = new Map();
const money = value => `${value.toFixed(2).replace('.', ',')} лв.`;
const escapeHTML = value => String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));

function renderProducts() {
  const sandwichGrid = document.getElementById('sandwich-grid');
  const drinkGrid = document.getElementById('drink-grid');
  for (const product of PRODUCTS) {
    const card = document.createElement('article');
    card.className = 'product-card';
    card.innerHTML = `
      <div class="product-top"><span class="food-icon" aria-hidden="true">${product.icon}</span><span class="product-tag">${escapeHTML(product.tag)}</span></div>
      <h4>${escapeHTML(product.name)}</h4>
      <p>${escapeHTML(product.description)}</p>
      <div class="product-bottom"><span class="product-price">${money(product.price)}</span><button class="add-button" type="button" data-add="${product.id}">+ Добави</button></div>`;
    (product.category === 'sandwich' ? sandwichGrid : drinkGrid).appendChild(card);
  }
}

function renderCart() {
  const itemsContainer = document.getElementById('cart-items');
  const emptyMessage = document.getElementById('cart-empty');
  const totalElement = document.getElementById('cart-total');
  const countElement = document.getElementById('cart-count');
  const countLabel = document.getElementById('cart-count-label');
  const checkoutButton = document.getElementById('checkout-button');
  const items = [...cart.entries()];
  const count = items.reduce((sum, [, quantity]) => sum + quantity, 0);
  const total = items.reduce((sum, [id, quantity]) => sum + PRODUCTS.find(product => product.id === id).price * quantity, 0);

  countElement.textContent = String(count);
  countLabel.textContent = `${count} ${count === 1 ? 'артикул' : 'артикула'}`;
  totalElement.textContent = money(total);
  emptyMessage.hidden = items.length > 0;
  itemsContainer.innerHTML = '';
  checkoutButton.disabled = items.length === 0;

  for (const [id, quantity] of items) {
    const product = PRODUCTS.find(item => item.id === id);
    const row = document.createElement('div');
    row.className = 'cart-row';
    row.innerHTML = `
      <div><div class="cart-product-name">${escapeHTML(product.name)}</div><div class="cart-product-price">${money(product.price)} × ${quantity} = ${money(product.price * quantity)}</div></div>
      <div class="quantity-control"><button type="button" data-action="decrease" data-id="${id}" aria-label="Премахни един">−</button><span>${quantity}</span><button type="button" data-action="increase" data-id="${id}" aria-label="Добави един">+</button></div>`;
    itemsContainer.appendChild(row);
  }
}

document.addEventListener('click', event => {
  const addButton = event.target.closest('[data-add]');
  if (addButton) {
    const id = addButton.dataset.add;
    cart.set(id, (cart.get(id) || 0) + 1);
    renderCart();
    addButton.textContent = '✓ Добавено';
    window.setTimeout(() => { addButton.textContent = '+ Добави'; }, 850);
    return;
  }

  const quantityButton = event.target.closest('[data-action][data-id]');
  if (quantityButton) {
    const id = quantityButton.dataset.id;
    const next = (cart.get(id) || 0) + (quantityButton.dataset.action === 'increase' ? 1 : -1);
    if (next <= 0) cart.delete(id); else cart.set(id, next);
    renderCart();
  }
});

document.getElementById('checkout-form').addEventListener('submit', async event => {
  event.preventDefault();
  const errorBox = document.getElementById('checkout-error');
  const resultBox = document.getElementById('order-result');
  const button = document.getElementById('checkout-button');
  const customerName = document.getElementById('customer-name').value.trim();
  errorBox.hidden = true;
  resultBox.hidden = true;

  if (cart.size === 0) return;
  if (!customerName) {
    errorBox.textContent = 'Моля, въведи име за поръчката.';
    errorBox.hidden = false;
    return;
  }

  button.disabled = true;
  button.textContent = 'Изпращане на поръчката…';
  const items = [...cart.entries()].map(([id, quantity]) => ({ id, quantity }));

  try {
    const response = await fetch('api.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'create', customerName, items, payment: 'cash' })
    });
    const responseText = await response.text();
    let data;
    try {
      data = JSON.parse(responseText);
    } catch {
      throw new Error('Сървърът не върна валиден JSON отговор. Провери PHP настройките и api.php.');
    }
    if (!response.ok || !data.success) throw new Error(data.message || 'Поръчката не беше изпратена.');

    resultBox.innerHTML = `<strong>Поръчката е приета!</strong><div class="order-number">${escapeHTML(data.order.number)}</div><p>Име: ${escapeHTML(data.order.customerName)}</p><p>Общо: ${money(data.order.total)}</p><p>Плащане: в брой на място.</p><p>Запомни номера и го покажи при получаване.</p>`;
    resultBox.hidden = false;
    cart.clear();
    renderCart();
    document.getElementById('customer-name').value = '';
    resultBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  } catch (error) {
    errorBox.textContent = error.message || 'Възникна проблем. Опитай отново.';
    errorBox.hidden = false;
  } finally {
    button.textContent = 'Потвърди поръчката →';
    button.disabled = cart.size === 0;
  }
});

renderProducts();
renderCart();
