'use strict';

const loginForm = document.getElementById('login-form');
const pinInput = document.getElementById('admin-pin');
const loginError = document.getElementById('login-error');
const loginPanel = document.getElementById('admin-login');
const ordersSection = document.getElementById('orders-section');
const ordersContainer = document.getElementById('admin-orders');
const ordersCount = document.getElementById('orders-count');
const refreshButton = document.getElementById('refresh-button');
let adminPin = '';

const statusText = {
  received: 'Нова поръчка',
  preparing: 'Приготвя се',
  ready: 'Готова за вземане',
  completed: 'Предадена'
};
const money = value => `${Number(value).toFixed(2).replace('.', ',')} лв.`;
const safe = value => String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));

async function apiRequest(payload) {
  const response = await fetch('api.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Admin-Pin': adminPin },
    body: JSON.stringify(payload)
  });
  const responseText = await response.text();
  let data;
  try {
    data = JSON.parse(responseText);
  } catch {
    throw new Error('Сървърът не върна валиден JSON отговор. Провери PHP настройките и api.php.');
  }
  if (!response.ok || !data.success) throw new Error(data.message || 'Възникна грешка.');
  return data;
}

function formatDate(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? '' : date.toLocaleString('bg-BG', { dateStyle: 'short', timeStyle: 'short' });
}

function renderOrders(orders) {
  ordersCount.textContent = `Общо поръчки: ${orders.length}`;
  if (!orders.length) {
    ordersContainer.innerHTML = '<div class="admin-empty">Все още няма постъпили поръчки.</div>';
    return;
  }

  ordersContainer.innerHTML = orders.map(order => {
    const itemsHTML = (order.items || []).map(item => `${safe(item.name)} × ${Number(item.quantity)} — ${money(item.lineTotal)}`).join('<br>');
    const status = statusText[order.status] || 'Неизвестен статус';
    const buttons = order.status === 'received'
      ? `<button data-status="preparing" data-id="${safe(order.id)}">Започни приготвяне</button>`
      : order.status === 'preparing'
        ? `<button data-status="ready" data-id="${safe(order.id)}">Маркирай като готова</button>`
        : order.status === 'ready'
          ? `<button data-status="completed" data-id="${safe(order.id)}">Предадена на клиента</button>`
          : '';
    return `<article class="admin-order">
      <div class="admin-order-head">
        <div><div class="admin-order-number">№ ${safe(order.number)}</div><div class="admin-order-meta">${safe(order.customerName)} · ${safe(formatDate(order.createdAt))}</div></div>
        <span class="status-pill status-${safe(order.status)}">${safe(status)}</span>
      </div>
      <div class="admin-order-items">${itemsHTML}<br><strong>Плащане: ${safe(order.payment || 'В брой на място')}</strong></div>
      <div class="admin-order-bottom"><div class="admin-order-total">Общо: ${money(order.total)}</div><div class="admin-actions">${buttons}</div></div>
    </article>`;
  }).join('');
}

async function loadOrders() {
  refreshButton.disabled = true;
  refreshButton.textContent = 'Зареждане…';
  try {
    const data = await apiRequest({ action: 'list' });
    renderOrders(data.orders);
  } catch (error) {
    ordersContainer.innerHTML = `<div class="admin-empty">${safe(error.message)}</div>`;
  } finally {
    refreshButton.disabled = false;
    refreshButton.textContent = '↻ Обнови';
  }
}

loginForm.addEventListener('submit', async event => {
  event.preventDefault();
  adminPin = pinInput.value.trim();
  loginError.textContent = '';
  try {
    await apiRequest({ action: 'list' });
    loginPanel.hidden = true;
    ordersSection.hidden = false;
    await loadOrders();
  } catch (error) {
    adminPin = '';
    loginError.textContent = error.message;
  }
});

refreshButton.addEventListener('click', loadOrders);
ordersContainer.addEventListener('click', async event => {
  const button = event.target.closest('[data-status][data-id]');
  if (!button) return;
  button.disabled = true;
  try {
    await apiRequest({ action: 'status', orderId: button.dataset.id, status: button.dataset.status });
    await loadOrders();
  } catch (error) {
    button.disabled = false;
    window.alert(error.message);
  }
});

// Обновява списъка автоматично на всеки 15 секунди, докато панелът е отворен.
window.setInterval(() => {
  if (!ordersSection.hidden && adminPin) loadOrders();
}, 15000);
