<?php
// PHP API със SQLite3 за предварителните поръчки.
// Демонстрационен PIN за служебната страница: 2468. Смени го преди реално публикуване.

declare(strict_types=1);

date_default_timezone_set('Europe/Sofia');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

const ADMIN_PIN = '2468';
const MENU = [
    'classic' => ['name' => 'Класически сандвич', 'price' => 5.50],
    'chicken' => ['name' => 'Пилешки сандвич', 'price' => 6.50],
    'caprese' => ['name' => 'Капрезе', 'price' => 6.00],
    'tuna' => ['name' => 'Сандвич с риба тон', 'price' => 6.80],
    'veggie' => ['name' => 'Вегетариански сандвич', 'price' => 5.80],
    'water' => ['name' => 'Минерална вода', 'price' => 1.50],
    'ayran' => ['name' => 'Айрян', 'price' => 2.00],
    'juice' => ['name' => 'Портокалов сок', 'price' => 2.80],
    'tea' => ['name' => 'Студен чай', 'price' => 2.50],
];

function respond(array $data, int $status = 200): never
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function readRequest(): array
{
    $raw = file_get_contents('php://input');
    $data = json_decode($raw ?: '{}', true);
    if (json_last_error() !== JSON_ERROR_NONE || !is_array($data)) {
        respond(['success' => false, 'message' => 'Невалидна заявка. Обнови страницата и опитай отново.'], 400);
    }
    return $data;
}

function checkAdminPin(): void
{
    $pin = $_SERVER['HTTP_X_ADMIN_PIN'] ?? '';
    if (!hash_equals(ADMIN_PIN, (string)$pin)) {
        respond(['success' => false, 'message' => 'Невалиден служебен PIN код.'], 401);
    }
}

function openDatabase(): SQLite3
{
    if (!class_exists('SQLite3')) {
        respond([
            'success' => false,
            'message' => 'SQLite3 не е активиран на сървъра. Помоли администратора да включи PHP разширението SQLite3.'
        ], 500);
    }

    $dataDirectory = __DIR__ . '/data';
    if (!is_dir($dataDirectory) && !@mkdir($dataDirectory, 0770, true) && !is_dir($dataDirectory)) {
        respond([
            'success' => false,
            'message' => 'Сървърът не може да създаде папката data. Необходими са права за запис за PHP.'
        ], 500);
    }

    if (!is_writable($dataDirectory)) {
        respond([
            'success' => false,
            'message' => 'Няма права за запис в папката data. Помоли администратора да разреши запис за PHP потребителя.'
        ], 500);
    }

    try {
        $database = new SQLite3($dataDirectory . '/orders.sqlite', SQLITE3_OPEN_READWRITE | SQLITE3_OPEN_CREATE);
        $database->enableExceptions(true);
        $database->busyTimeout(5000);
        $database->exec('PRAGMA foreign_keys = ON');
        $database->exec('PRAGMA busy_timeout = 5000');

        $database->exec(
            'CREATE TABLE IF NOT EXISTS orders (
                id TEXT PRIMARY KEY,
                number TEXT NOT NULL UNIQUE,
                customer_name TEXT NOT NULL,
                total REAL NOT NULL,
                payment TEXT NOT NULL,
                status TEXT NOT NULL,
                created_at TEXT NOT NULL
            )'
        );
        $database->exec(
            'CREATE TABLE IF NOT EXISTS order_items (
                item_id INTEGER PRIMARY KEY AUTOINCREMENT,
                order_id TEXT NOT NULL,
                product_id TEXT NOT NULL,
                name TEXT NOT NULL,
                price REAL NOT NULL,
                quantity INTEGER NOT NULL,
                line_total REAL NOT NULL,
                FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
            )'
        );
        $database->exec('CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at)');
        $database->exec('CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON order_items(order_id)');

        return $database;
    } catch (Throwable $error) {
        error_log('Zakusvalnya SQLite error: ' . $error->getMessage());
        respond([
            'success' => false,
            'message' => 'Базата данни не може да бъде отворена. Провери дали SQLite3 е активиран и дали PHP има права за запис в папката data.'
        ], 500);
    }
}

function orderItemsForDatabase(SQLite3 $database, string $orderId): array
{
    $statement = $database->prepare(
        'SELECT product_id, name, price, quantity, line_total FROM order_items WHERE order_id = :order_id ORDER BY item_id'
    );
    $statement->bindValue(':order_id', $orderId, SQLITE3_TEXT);
    $result = $statement->execute();
    $items = [];

    while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
        $items[] = [
            'id' => $row['product_id'],
            'name' => $row['name'],
            'price' => (float)$row['price'],
            'quantity' => (int)$row['quantity'],
            'lineTotal' => (float)$row['line_total'],
        ];
    }

    return $items;
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    respond(['success' => false, 'message' => 'Използвай POST заявка.'], 405);
}

$request = readRequest();
$action = $request['action'] ?? '';

if ($action === 'create') {
    $customerName = trim(strip_tags((string)($request['customerName'] ?? '')));
    $requestedItems = $request['items'] ?? [];
    $nameLength = preg_match_all('/./us', $customerName);

    if ($customerName === '' || $nameLength === false || $nameLength > 50) {
        respond(['success' => false, 'message' => 'Въведи име до 50 символа.'], 400);
    }
    if (!is_array($requestedItems) || count($requestedItems) < 1 || count($requestedItems) > 20) {
        respond(['success' => false, 'message' => 'Кошницата е празна или съдържа твърде много различни артикули.'], 400);
    }

    // Цените се вземат от менюто на сървъра, а не от браузъра.
    $items = [];
    $total = 0.0;
    foreach ($requestedItems as $requested) {
        if (!is_array($requested)) {
            respond(['success' => false, 'message' => 'Невалиден артикул в кошницата.'], 400);
        }
        $productId = (string)($requested['id'] ?? '');
        $quantity = filter_var($requested['quantity'] ?? null, FILTER_VALIDATE_INT);
        if (!isset(MENU[$productId]) || $quantity === false || $quantity < 1 || $quantity > 25) {
            respond(['success' => false, 'message' => 'Има невалиден продукт или количество. Обнови страницата и опитай отново.'], 400);
        }

        $product = MENU[$productId];
        $lineTotal = round($product['price'] * $quantity, 2);
        $total += $lineTotal;
        $items[] = [
            'id' => $productId,
            'name' => $product['name'],
            'price' => $product['price'],
            'quantity' => $quantity,
            'lineTotal' => $lineTotal,
        ];
    }

    try {
        $database = openDatabase();
        $database->exec('BEGIN IMMEDIATE TRANSACTION');

        $todayPrefix = 'Z' . date('ymd') . '-';
        $sequence = 0;
        $numberQuery = $database->prepare('SELECT number FROM orders WHERE number LIKE :pattern');
        $numberQuery->bindValue(':pattern', $todayPrefix . '%', SQLITE3_TEXT);
        $numberResult = $numberQuery->execute();
        while ($existing = $numberResult->fetchArray(SQLITE3_ASSOC)) {
            $oldSequence = (int)substr((string)$existing['number'], strlen($todayPrefix));
            $sequence = max($sequence, $oldSequence);
        }

        $orderId = bin2hex(random_bytes(8));
        $orderNumber = $todayPrefix . str_pad((string)($sequence + 1), 3, '0', STR_PAD_LEFT);
        $createdAt = date('c');
        $payment = 'В брой на място';
        $status = 'received';

        $insertOrder = $database->prepare(
            'INSERT INTO orders (id, number, customer_name, total, payment, status, created_at)
             VALUES (:id, :number, :customer_name, :total, :payment, :status, :created_at)'
        );
        $insertOrder->bindValue(':id', $orderId, SQLITE3_TEXT);
        $insertOrder->bindValue(':number', $orderNumber, SQLITE3_TEXT);
        $insertOrder->bindValue(':customer_name', $customerName, SQLITE3_TEXT);
        $insertOrder->bindValue(':total', round($total, 2), SQLITE3_FLOAT);
        $insertOrder->bindValue(':payment', $payment, SQLITE3_TEXT);
        $insertOrder->bindValue(':status', $status, SQLITE3_TEXT);
        $insertOrder->bindValue(':created_at', $createdAt, SQLITE3_TEXT);
        $insertOrder->execute();

        $insertItem = $database->prepare(
            'INSERT INTO order_items (order_id, product_id, name, price, quantity, line_total)
             VALUES (:order_id, :product_id, :name, :price, :quantity, :line_total)'
        );
        foreach ($items as $item) {
            $insertItem->bindValue(':order_id', $orderId, SQLITE3_TEXT);
            $insertItem->bindValue(':product_id', $item['id'], SQLITE3_TEXT);
            $insertItem->bindValue(':name', $item['name'], SQLITE3_TEXT);
            $insertItem->bindValue(':price', $item['price'], SQLITE3_FLOAT);
            $insertItem->bindValue(':quantity', $item['quantity'], SQLITE3_INTEGER);
            $insertItem->bindValue(':line_total', $item['lineTotal'], SQLITE3_FLOAT);
            $insertItem->execute();
            $insertItem->reset();
        }

        $database->exec('COMMIT');
        $database->close();

        respond([
            'success' => true,
            'order' => [
                'id' => $orderId,
                'number' => $orderNumber,
                'customerName' => $customerName,
                'items' => $items,
                'total' => round($total, 2),
                'payment' => $payment,
                'status' => $status,
                'createdAt' => $createdAt,
            ],
        ]);
    } catch (Throwable $error) {
        if (isset($database) && $database instanceof SQLite3) {
            try { $database->exec('ROLLBACK'); } catch (Throwable $ignored) {}
            $database->close();
        }
        error_log('Zakusvalnya order create error: ' . $error->getMessage());
        respond(['success' => false, 'message' => 'Поръчката не беше записана. Провери настройките на SQLite3 и правата на папката data.'], 500);
    }
}

if ($action === 'list') {
    checkAdminPin();
    $database = openDatabase();
    $result = $database->query('SELECT * FROM orders ORDER BY created_at DESC, rowid DESC');
    $orders = [];

    while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
        $orderId = (string)$row['id'];
        $orders[] = [
            'id' => $orderId,
            'number' => (string)$row['number'],
            'customerName' => (string)$row['customer_name'],
            'items' => orderItemsForDatabase($database, $orderId),
            'total' => (float)$row['total'],
            'payment' => (string)$row['payment'],
            'status' => (string)$row['status'],
            'createdAt' => (string)$row['created_at'],
        ];
    }

    $database->close();
    respond(['success' => true, 'orders' => $orders]);
}

if ($action === 'status') {
    checkAdminPin();
    $orderId = (string)($request['orderId'] ?? '');
    $newStatus = (string)($request['status'] ?? '');
    $allowedStatuses = ['preparing', 'ready', 'completed'];

    if ($orderId === '' || !in_array($newStatus, $allowedStatuses, true)) {
        respond(['success' => false, 'message' => 'Невалидна промяна на статуса.'], 400);
    }

    $database = openDatabase();
    $statement = $database->prepare('UPDATE orders SET status = :status WHERE id = :id');
    $statement->bindValue(':status', $newStatus, SQLITE3_TEXT);
    $statement->bindValue(':id', $orderId, SQLITE3_TEXT);
    $statement->execute();

    $check = $database->prepare('SELECT COUNT(*) AS total FROM orders WHERE id = :id');
    $check->bindValue(':id', $orderId, SQLITE3_TEXT);
    $checkResult = $check->execute();
    $exists = (int)$checkResult->fetchArray(SQLITE3_ASSOC)['total'] > 0;
    $database->close();

    if (!$exists) {
        respond(['success' => false, 'message' => 'Поръчката не е намерена.'], 404);
    }
    respond(['success' => true]);
}

respond(['success' => false, 'message' => 'Непозната операция.'], 400);
